package com.chaoyue.dbflowdemo;

import android.app.Application;

import com.raizlabs.android.dbflow.config.FlowConfig;
import com.raizlabs.android.dbflow.config.FlowLog;
import com.raizlabs.android.dbflow.config.FlowManager;

/**
 * Created by Administrator on 2018/1/19.
 */

public class MyApplication extends Application {


    @Override
    public void onCreate() {
        super.onCreate();
        dbFlowInit();
    }

    private void dbFlowInit() {
        try {
            // FlowManager.init(this);//这句也可以初始化
            FlowManager.init(new FlowConfig.Builder(getApplicationContext())
                    .openDatabasesOnInit(true) .build());
            FlowLog.setMinimumLoggingLevel(FlowLog.Level.V);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
