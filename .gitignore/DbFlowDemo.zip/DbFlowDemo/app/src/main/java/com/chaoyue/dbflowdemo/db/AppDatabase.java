package com.chaoyue.dbflowdemo.db;

import com.chaoyue.dbflowdemo.Good;
import com.raizlabs.android.dbflow.annotation.Database;
import com.raizlabs.android.dbflow.annotation.Migration;
import com.raizlabs.android.dbflow.sql.SQLiteType;
import com.raizlabs.android.dbflow.sql.migration.AlterTableMigration;;


/**
 * Created by Administrator on 2018/1/19.
 */

@Database(name = AppDatabase.NAME,version = AppDatabase.VERSION)
public class AppDatabase {

    public static final String NAME="NF_AppDatabase1";
    public static final int VERSION=3;

    @Migration(version = VERSION, database = AppDatabase.class)
    public static class Migration2UserData extends AlterTableMigration<Good> {

        public Migration2UserData(Class<Good> table) {
            super(table);
        }

        @Override
        public void onPreMigrate() {
            addColumn(SQLiteType.TEXT, "extraCoumen");
        }
    }

}
